# QuickStats
Descriptive statistics for Arduino float arrays
